package com.meuprojeto;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;



@Controller
public class WebController {

    @GetMapping("/")
    public String viewHome() {
        return "hub"; // Sem a extensão .html, o Spring irá procurar por um arquivo chamado hub.html em src/main/resources/templates
    }

    @GetMapping("/horarios")
    public String viewHorarios() {
        return "horarios"; // Assumindo que você tem um arquivo horarios.html
    }

    @GetMapping("/salas")
    public String viewSalas() {
        return "salas"; // Assumindo que você tem um arquivo salas.html
    }


@PostMapping("/upload")
public ResponseEntity<String> handleFileUpload(@RequestParam("file") MultipartFile file) {
    // Seu código de upload aqui
    if (!file.isEmpty()) {
        try {
            // Você pode querer substituir "user.dir" pelo local exato onde você quer salvar
            Files.copy(file.getInputStream(), Paths.get(System.getProperty("user.dir") + "/" + file.getOriginalFilename()));
            return ResponseEntity.ok("Arquivo carregado com sucesso: " + file.getOriginalFilename());
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Falha ao carregar o arquivo: " + e.getMessage());
        }
    } else {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Arquivo vazio não pode ser carregado");
    }
}

}


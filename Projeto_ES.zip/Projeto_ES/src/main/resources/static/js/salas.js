let table;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect, false);
});

function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

function parseFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
    };
    reader.readAsText(file);
}

function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift(); // Remove a primeira linha e considera-a como cabecalhos
    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = row[index];
        });
        return obj;
    });
    return { headers, data };
}

function createTable(headers, data) {
    const labHeaders = headers.filter(header => header.startsWith('Laborat'));
    const arqHeaders = headers.filter(header => header.startsWith('Arq'));

    // Filtra colunas originais para excluir as que comecam com Arq e Laborat
    const filteredHeaders = headers.filter(header => !header.startsWith('Laborat') && !header.startsWith('Arq'));

    const columns = filteredHeaders.map(header => {
        return { 
            title: header, 
            field: header,
            headerFilter: 'input' 
        };
    });

    // coluna de laboratorios na quinta posicao-> sexta coluna
    columns.splice(5, 0, { 
        title: "Laboratórios", 
        field: "Laboratórios",
        headerFilter: 'input',
    });

    // coluna de laboratorios na sexta posicao-> setima coluna
    columns.splice(6, 0, { 
        title: "Arquivos", 
        field: "Arquivos",
        headerFilter: 'input'
    });

    const labData = data.map(row => {
        const labs = labHeaders.filter(header => row[header] === 'X').map(header => header.replace('Laboratório de ', ''));
        const labColumnValue = labs.length > 0 ? labs.join(', ') : '';
        
        const arqs = arqHeaders.filter(header => row[header] === 'X');
        const arqColumnValue = arqs.length > 0 ? arqs.join(', ') : '';
        
        return { ...row, Laboratórios: labColumnValue, Arquivos: arqColumnValue };
    });

    table = new Tabulator("#tableContainer", {
        data: labData,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: filteredHeaders[0], dir: "asc" }]
    });
}

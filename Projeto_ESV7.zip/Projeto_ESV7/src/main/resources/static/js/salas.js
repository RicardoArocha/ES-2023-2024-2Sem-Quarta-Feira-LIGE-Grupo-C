let table;

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect, false);
});

function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

function parseFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
    };
    reader.readAsText(file);
}

function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift(); // Remove a primeira linha e considera-a como cabecalhos
    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = row[index];
        });
        return obj;
    });
    return { headers, data };
}

function createTable(headers, data) {
    const labHeaders = headers.filter(header => header.startsWith('Laborat'));
    const arqHeaders = headers.filter(header => header.startsWith('Arq'));

    // Filtra colunas originais para excluir as que comecam com Arq e Laborat
    const filteredHeaders = headers.filter(header => !header.startsWith('Laborat') && !header.startsWith('Arq'));

    const columns = filteredHeaders.map(header => {
        return { 
            title: header, 
            field: header,
            headerFilter: 'input' 
        };
    });

    // coluna de laboratorios na quinta posicao-> sexta coluna
    columns.splice(5, 0, { 
        title: "Laboratórios", 
        field: "Laboratórios",
        headerFilter: 'input',
    });

    // coluna de laboratorios na sexta posicao-> setima coluna
    columns.splice(6, 0, { 
        title: "Arquivos", 
        field: "Arquivos",
        headerFilter: 'input'
    });

    const labData = data.map(row => {
        const labs = labHeaders.filter(header => row[header] === 'X').map(header => header.replace('Laboratório de ', ''));
        const labColumnValue = labs.length > 0 ? labs.join(', ') : '';
        
        const arqs = arqHeaders.filter(header => row[header] === 'X');
        const arqColumnValue = arqs.length > 0 ? arqs.join(', ') : '';
        
        return { ...row, Laboratórios: labColumnValue, Arquivos: arqColumnValue };
    });

    table = new Tabulator("#tableContainer", {
        data: labData,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: filteredHeaders[0], dir: "asc" }]
    });

}

    /* metes esta função no salas.js */
function exportTabulatorToCSV() {
    var headers = table.getColumns().filter(column => column.isVisible()).map(column => column.getDefinition().title);
    var csvContent = [headers.join(',')];

    table.getData().forEach(row => {
        var rowData = headers.map(header => row[header]);
        csvContent.push(rowData.join(','));
    });

    return csvContent.join('\n');
}

/* metes esta função no salas.js */

function uploadFile() {
    var updatedCSV = exportTabulatorToCSV();
    var blob = new Blob([updatedCSV], { type: 'text/csv;charset=utf-8;' });

    var formData = new FormData();
    formData.append('file', blob, 'caracterizacaodassalas.csv');
    //aqui vais ter de mudar de upload para upload horario e no salas.js mudas para upload-salas
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            return response.text();
        }
        throw new Error('Falha ao salvar o arquivo.');
    })
    .then(text => console.log(text))
    .catch(error => console.error(error));
}

function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

function checkSchedule() {
    const horaInicio = document.getElementById("horaInput").value + ":00";
    const data = document.getElementById("dataInput").value;
    const dataBem= parseDate(data);

    checkScheduleByFields(dataBem, horaInicio);
}

function checkScheduleByFields(data, horaInicio) {
    fetch(`/check-schedule?data=${data}&horaInicio=${horaInicio}`)
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log(data);
            if (data.length > 0) {
                console.log(data);
                data.forEach(sala => {
                    if (table.getRow(1, sala)) {
                        table.deleteRow(1, sala);
                    } else {
                        console.warn(`Row for room ${sala} not found in the table.`);
                    }
                });
            }
        })
        .catch(error => {
            console.error('There was a problem with the fetch operation:', error);
            document.getElementById("scheduleStatus").innerText = "An error occurred while checking the schedule.";
        });
}


function parseDate(diaValue) {
    const [year, day, month] = diaValue.split('-'); // Split the date string into year, day, and month
    const formattedDate = `${month}/${day}/${year}`; // Construct the formatted date string
    return formattedDate;
}





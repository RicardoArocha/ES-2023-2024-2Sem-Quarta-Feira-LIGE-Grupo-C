let table;

// Aguarda o carregamento do DOM para inicializar os componentes
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect, false);
    document.getElementById('saveFileButton').addEventListener('click', saveFileToServer);
    fetchScheduleFile(); 
});

// Manipula a seleção de arquivos CSV, dispara a leitura e processamento do arquivo
function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

// Lê o arquivo CSV e carrega seus dados na tabela
function parseFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
        createColumnControls(data.headers);
    };
    reader.readAsText(file);
}

function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift(); // Lê os cabeçalhos
    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = row[index] || ""; // Garante consistência
        });
        return obj;
    });

    return { headers, data };
}

// Calcula a semana do ano com base na data fornecida

function calculateWeekOfYear(dateStr) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const start = new Date(date.getFullYear(), 0, 1);
    const weekNo = Math.ceil(((date - start) / (24 * 60 * 60 * 1000) + start.getDay() + 1) / 7);
    return Math.max(weekNo, 1);
}

function calculateSemesterWeek(dateStr, semesterStartStr) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const semesterStart = new Date(semesterStartStr);
    let weekNo = Math.floor((date - semesterStart) / (7 * 24 * 60 * 60 * 1000)) + 1;

    return (weekNo < 1 || weekNo > 18) ? "-" : weekNo;
}

function populateAdditionalColumns(data) {
    data.forEach(row => {
        const dateStr = row['Data da aula'];
        if (dateStr) {
            const weekOfYear = calculateWeekOfYear(dateStr);
            const firstSemesterWeek = calculateSemesterWeek(dateStr, '2022-09-01');
            const secondSemesterWeek = calculateSemesterWeek(dateStr, '2023-01-01');

            row['Semana do Ano'] = weekOfYear;
            row['Semana do 1º Semestre'] = firstSemesterWeek;
            row['Semana do 2º Semestre'] = secondSemesterWeek;
        } else {
            row['Semana do Ano'] = "-";
            row['Semana do 1º Semestre'] = "-";
            row['Semana do 2º Semestre'] = "-";
        }
    });
}



function createTable(headers, data) {
    // Remover duplicatas para garantir colunas únicas
    const uniqueHeaders = Array.from(new Set(headers)); // Elimina cabeçalhos duplicados

    const columns = uniqueHeaders.map(header => ({
        title: header,
        field: header,
        headerFilter: 'input'
    }));

    // Configurações da Tabulator
    table = new Tabulator("#tableContainer", {
        data: data, // atribui os dados
        columns: columns, // atribui as colunas
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }]
    });
}

// Função chamada quando o botão 'Substituir' é clicado
function markSubstitution(data) {
    function markSubstitution(data) {
        // Armazena as informações da aula que precisa de substituição
        localStorage.setItem('substitutionData', JSON.stringify(data));
        // Redireciona para a página de salas
        window.location.href = '/salas.html'; // Substitua '/salas.html' pelo caminho correto da sua página de salas
    }
}
    table = new Tabulator("#tableContainer", {
        data: data,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }]
    });


// Cria controles de coluna para manipular a visibilidade das colunas
function createColumnControls(headers) {
    const controlsContainer = document.getElementById('column-controls');
    controlsContainer.innerHTML = '';

    headers.forEach(header => {
        const button = document.createElement('button');
        button.textContent = header;
        button.setAttribute('data-column', header);
        button.onclick = () => toggleColumn(header);
        controlsContainer.appendChild(button);
    });
}

// Alterna a visibilidade de uma coluna
function toggleColumn(column) {
    const col = table.getColumn(column);
    col.toggle();
    const button = document.querySelector(`#column-controls button[data-column='${column}']`);
    if (!col.isVisible()) {
        button.classList.add('button-inactive');
    } else {
        button.classList.remove('button-inactive');
    }
}

// Aplica um filtro "OU" para buscar dados na tabela com base no valor inserido
function applyOrFilter() {
    const searchValue = document.getElementById('or-search-input').value.trim();
    if (searchValue) {
        const filterParams = {};
        table.getColumns().forEach(column => {
            filterParams[column.getField()] = searchValue;
        });
        table.setFilter(orFilterFunction, filterParams);
    } else {
        table.clearFilter();
    }
}

// Define a função de filtro para a pesquisa "OU"
function orFilterFunction(data, filterParams) {
    return Object.keys(filterParams).some(key => {
        return data[key] && data[key].toString().toLowerCase().includes(filterParams[key].toLowerCase());
    });
}

// Exporta dados visíveis do Tabulator para CSV e envia para o servidor
function uploadFile() {
    var updatedCSV = exportTabulatorToCSV2();
    var blob = new Blob([updatedCSV], { type: 'text/csv;charset=utf-8;' });

    var formData = new FormData();
    formData.append('file', blob, 'HorarioDeExemploAtualizado.csv');

    fetch('/upload-horarios', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            return response.text();
        }
        throw new Error('Falha ao salvar o arquivo.');
    })
    .then(text => console.log(text))
    .catch(error => console.error(error));
}


function exportTabulatorToCSV() {
    // Adiciona as colunas adicionais ao CSV
    const headers = table.getColumns().map(column => column.getDefinition().title);

    const additionalHeaders = ['Semana do Ano', 'Semana do 1º Semestre', 'Semana do 2º Semestre'];
    const uniqueHeaders = Array.from(new Set(headers.concat(additionalHeaders)));

    const data = table.getData();

    // Preenche as colunas adicionais
    populateAdditionalColumns(data);

    const csvData = data.map(row => {
        return uniqueHeaders.map(header => row[header] || "").join(";");
    });

    return [uniqueHeaders.join(';'), ...csvData].join('\n');
}


// Função para salvar o arquivo no servidor
function saveFileToServer() {
    try {
        const csvContent = exportTabulatorToCSV();
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

        const formData = new FormData();
        formData.append('file', blob, 'HorarioDeExemploAtualizado.csv');

        fetch('/upload-horarios', {
            method: 'POST',
            body: formData
        })
        .then(response => {
            if (response.ok) {
                alert("Ficheiro guardado com sucesso!");
            } else {
                throw new Error('Falha ao guardar o ficheiro.');
            }
        })
        .catch(error => {
            console.error('Erro ao guardar o ficheiro:', error);
            alert("Erro ao guardar o ficheiro.");
        });
    } catch (error) {
        console.error("Erro ao tentar salvar o ficheiro:", error);
        alert("Erro ao tentar salvar o ficheiro.");
    }
}

// Função para carregar o arquivo do servidor
function fetchScheduleFile() {
    fetch('/HorarioDeExemploAtualizado.csv') // Verifique se o caminho está correto
        .then(response => {
            if (response.ok) {
                return response.text();
            }
            throw new Error("Erro ao carregar o ficheiro do servidor");
        })
        .then(csvData => {
            const data = parseCSV(csvData);

            // Verifique se os dados são válidos
            if (!data || !data.headers || !data.data) {
                throw new Error("Dados inválidos ao carregar o CSV");
            }

            createTable(data.headers, data.data); // Criar tabela sem colunas extras
            createColumnControls(data.headers); // Configurar controle das colunas
        })
        .catch(error => {
            console.error('Erro ao carregar o ficheiro do servidor:', error);
        });
}
function exportTabulatorToCSV2() {
    var headers = table.getColumns().filter(column => column.isVisible()).map(column => column.getDefinition().title);
    var csvContent = [headers.join(';')];

    table.getData().forEach(row => {
        var rowData = headers.map(header => row[header]);
        csvContent.push(rowData.join(';'));
    });

    return csvContent.join('\n');
}
let table;
let roomData = []; // Dados das salas
let scheduleData = []; // Dados dos horários

// Evento para inicializar a página

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect2, false);
    loadRoomData();
    loadScheduleData();
    checkPreselectedSchedule();
    const substitutionData = JSON.parse(localStorage.getItem('substitutionData'));
    if (substitutionData) {
        applySubstitutionFilters(substitutionData);
    }
});

// Carrega os dados pré-selecionados de horários, se houver
function checkPreselectedSchedule() {
    const storedData = localStorage.getItem("scheduleData");
    if (storedData) {
        const scheduleData = JSON.parse(storedData);
        document.getElementById('dayOfWeek').value = scheduleData['Data da aula'];
        document.getElementById('startTime').value = scheduleData['Hora início da aula'];
        checkAvailability();
    }
}

// Manipula a seleção de arquivo e processa o arquivo CSV
function handleFileSelect2(event) {
    const file = event.target.files[0];
    parseFile2(file);
}

// Lê e processa o arquivo CSV carregado
function parseFile2(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV2(contents);
        createTable(data.headers, data.data);
    };
    reader.readAsText(file);
}

// Carrega dados das salas a partir de um arquivo CSV
function loadRoomData() {
    const roomCsvUrl = '/caracterizacaodasSalas.csv';
    fetch(roomCsvUrl)
        .then(response => response.text())
        .then(csvData => {
            const parsedData = parseCSV2(csvData); // Aqui é onde você deve capturar os dados parseados
            roomData = parsedData.data; // Agora roomData é apenas o array 'data'
            if(parsedData.headers && parsedData.data) { // Certifique-se de que ambos estão definidos
                createTable(parsedData.headers, parsedData.data);
            }
        })
        .catch(error => console.error('Erro ao carregar os dados das salas:', error));
}

// Carrega dados de horário a partir de um arquivo CSV
function loadScheduleData() {
    const scheduleCsvUrl = '/HorarioDeExemploAtualizado.csv';
    fetch(scheduleCsvUrl)
        .then(response => response.text())
        .then(csvData => {
            scheduleData = parseCSV2(csvData).data;
            console.log("Dados dos horários carregados", scheduleData);
        })
        .catch(error => console.error('Erro ao carregar os dados dos horários:', error));
}

// Processa dados CSV em um formato utilizável
function parseCSV2(csvData) {
    const rows = csvData.trim().split('\n');
    const headers = rows.shift().split(';').map(header => header.trim());
    const data = rows.map(row => {
        const values = row.split(';').map(value => value.trim());
        return headers.reduce((obj, header, index) => {
            obj[header] = values[index] || "";
            return obj;
        }, {});
    });
    return { headers, data };
}

// Verifica a disponibilidade das salas com base na seleção de data e hora
function checkAvailability() {
    const startTimeInput = document.getElementById('startTime').value;
    const dayInput = document.getElementById('dayOfWeek').value;
    const searchDate = dayInput.split('-').reverse().join('/');
    const searchStartTime = convertTimeToMinutes(startTimeInput);

    const relevantSchedules = scheduleData.filter(schedule => {
        let roomBookedDate = schedule['Data da aula'];
        let roomStartTime = convertTimeToMinutes(schedule['Hora início da aula']);
        let roomEndTime = convertTimeToMinutes(schedule['Hora fim da aula']);
        return roomBookedDate === searchDate && searchStartTime >= roomStartTime && searchStartTime < roomEndTime;
    });

    updateTableWithAvailability(relevantSchedules);
}

// Atualiza a tabela com salas disponíveis
function updateTableWithAvailability(relevantSchedules) {
    let availableRooms = roomData.filter(room => {
        return !relevantSchedules.some(schedule => schedule['Sala atribuída à aula'] === room['Nome sala']);
    });
    table.setData(availableRooms);
    console.log(`Salas disponíveis: ${availableRooms.map(r => r.roomName).join(', ')}`);
}

// Converte hora no formato HH:MM para minutos
function convertTimeToMinutes(timeString) {
    const [hours, minutes] = timeString.split(':').map(Number);
    return (hours * 60) + minutes;
}

// Redefine os filtros para o estado original
function resetFilters() {
    document.getElementById('startTime').value = '';
    document.getElementById('dayOfWeek').value = '';
    if(table) {
        table.clearFilter(true); // remove filtros, mas mantém os dados da tabela
        table.setData(roomData); // redefine os dados da tabela para o conjunto de dados original
    }
}

// Cria a tabela com os dados das salas
function createTable(headers, data) {
    if(!headers || !data) {
        console.error('Dados ou cabeçalhos indefinidos para criar a tabela');
        return; // Sai da função se headers ou data não estiverem definidos
    }
    const columns = headers.map(header => ({
        title: header,
        field: header,
        headerFilter: 'input',
    }));

    // Adiciona uma coluna de ação com botões para marcar a substituição
    columns.push({
        title: "Ações",
        headerSort: false,
        formatter: function(cell, formatterParams) {
            const button = document.createElement("button");
            button.textContent = "Marcar Substituição";
            button.onclick = function() {
                confirmSubstitution(cell.getRow().getData());
            };
            return button;
        },
        width: 200,
        hozAlign: "center",
    });

    // Configura a tabela com as colunas e os dados
    table = new Tabulator("#tableContainer", {
        data: data,
        columns: columns,
        layout: "fitDataStretch",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }],
    });
}

// Função chamada quando o botão de 'Marcar Substituição' é clicado
function confirmSubstitution(rowData) {
    // Implemente a lógica de confirmação de substituição aqui.
    // Isso pode envolver armazenar os dados selecionados para substituição e
    // depois redirecionar para a página de horários ou atualizar diretamente via API
    console.log('Substituição marcada para a sala:', rowData);
    
    // Exemplo de armazenamento de dados e redirecionamento
    localStorage.setItem('selectedRoomForSubstitution', JSON.stringify(rowData));
    window.location.href = '/pagina-de-horarios'; // Atualize com o caminho correto da página de horários
}


// Carrega os dados atualizados para o servidor
function uploadFile2() {
    var fileInput = document.getElementById('csvFileInput');
    var file = fileInput.files[0];
    
    var formData = new FormData();
    formData.append('file', file, 'caracterizacaodassalas.csv');

    fetch('/upload-salas', { // Endpoint atualizado para o upload de salas
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            alert('Arquivo de salas salvo com sucesso.');
            loadRoomData(); // Recarregar os dados da sala após o sucesso do upload
        } else {
            throw new Error('Falha ao salvar o arquivo de salas.');
        }
    })
    .catch(error => {
        console.error('Erro ao salvar o arquivo de salas:', error);
        alert('Erro ao salvar o arquivo de salas.');
    });
}


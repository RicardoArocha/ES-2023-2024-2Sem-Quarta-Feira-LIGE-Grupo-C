let table;

// Aguarda o carregamento do DOM para inicializar os componentes
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect, false);
    document.getElementById('saveFileButton').addEventListener('click', saveFileToServer);
    fetchScheduleFile(); 
});

// Manipula a seleção de arquivos CSV, dispara a leitura e processamento do arquivo
function handleFileSelect(event) {
    const file = event.target.files[0];
    parseFile(file);
}

// Lê o arquivo CSV e carrega seus dados na tabela
function parseFile(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
        createColumnControls(data.headers);
    };
    reader.readAsText(file);
}

// Parseia os dados CSV e retorna um objeto com cabeçalhos e dados
function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift();
    headers.push('Semana do Ano', 'Semana do 1º Semestre', 'Semana do 2º Semestre');

    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = row[index] || "";
            if (header === 'Data da aula') {
                obj['Semana do Ano'] = calculateWeekOfYear(obj['Data da aula']);
                obj['Semana do 1º Semestre'] = calculateSemesterWeek(obj['Data da aula'], '2022-10-01', 1);
                obj['Semana do 2º Semestre'] = calculateSemesterWeek(obj['Data da aula'], '2023-02-01', 2);
            }
        });
        return obj;
    });
    return { headers, data };
}

// Calcula a semana do ano com base na data fornecida
function calculateWeekOfYear(dateStr) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const start = new Date(date.getFullYear(), 0, 1);
    const weekNo = Math.ceil(((date - start) / (24 * 60 * 60 * 1000) + start.getDay() + 1) / 7);
    return Math.max(weekNo, 1);
}

// Calcula a semana do semestre com base na data fornecida e na data de início do semestre
function calculateSemesterWeek(dateStr, semesterStartStr, semesterNumber) {
    const date = new Date(dateStr.split('/').reverse().join('-'));
    const semesterStart = new Date(semesterStartStr);
    let weekNo = Math.floor((date - semesterStart) / (1000 * 60 * 60 * 24 * 7)) + 1;
    return (weekNo < 1 || weekNo > 15) ? "-" : weekNo;
}

function createTable(headers, data) {
    // Mapeia os cabeçalhos para colunas
    const columns = headers.map(header => ({
        title: header,
        field: header,
        headerFilter: 'input'
    }));

    // Adiciona a coluna de ação com o botão 'Marcar Substituição'
    columns.push({
        title: "Marcar Substituição",
        headerSort: false,
        formatter: function(cell, formatterParams) {
            let button = document.createElement("button");
            button.innerHTML = "Substituir";
            button.onclick = function() {
                markSubstitution(cell.getRow().getData());
            };
            return button;
        },
        width: 150
    });

    // Configurações da Tabulator
    table = new Tabulator("#tableContainer", {
        data: data, // atribui os dados
        columns: columns, // atribui as colunas
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }]
    });
}

// Função chamada quando o botão 'Substituir' é clicado
function markSubstitution(data) {
    function markSubstitution(data) {
        // Armazena as informações da aula que precisa de substituição
        localStorage.setItem('substitutionData', JSON.stringify(data));
        // Redireciona para a página de salas
        window.location.href = '/salas.html'; // Substitua '/salas.html' pelo caminho correto da sua página de salas
    }
}
    table = new Tabulator("#tableContainer", {
        data: data,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: headers[0], dir: "asc" }]
    });


// Cria controles de coluna para manipular a visibilidade das colunas
function createColumnControls(headers) {
    const controlsContainer = document.getElementById('column-controls');
    controlsContainer.innerHTML = '';

    headers.forEach(header => {
        const button = document.createElement('button');
        button.textContent = header;
        button.setAttribute('data-column', header);
        button.onclick = () => toggleColumn(header);
        controlsContainer.appendChild(button);
    });
}

// Alterna a visibilidade de uma coluna
function toggleColumn(column) {
    const col = table.getColumn(column);
    col.toggle();
    const button = document.querySelector(`#column-controls button[data-column='${column}']`);
    if (!col.isVisible()) {
        button.classList.add('button-inactive');
    } else {
        button.classList.remove('button-inactive');
    }
}

// Aplica um filtro "OU" para buscar dados na tabela com base no valor inserido
function applyOrFilter() {
    const searchValue = document.getElementById('or-search-input').value.trim();
    if (searchValue) {
        const filterParams = {};
        table.getColumns().forEach(column => {
            filterParams[column.getField()] = searchValue;
        });
        table.setFilter(orFilterFunction, filterParams);
    } else {
        table.clearFilter();
    }
}

// Define a função de filtro para a pesquisa "OU"
function orFilterFunction(data, filterParams) {
    return Object.keys(filterParams).some(key => {
        return data[key] && data[key].toString().toLowerCase().includes(filterParams[key].toLowerCase());
    });
}

// Exporta dados visíveis do Tabulator para CSV e envia para o servidor
function uploadFile() {
    var updatedCSV = exportTabulatorToCSV();
    var blob = new Blob([updatedCSV], { type: 'text/csv;charset=utf-8;' });
    

    var formData = new FormData();
    formData.append('file', blob, 'HorarioDeExemploAtualizado.csv');
    //aqui vais ter de mudar de upload para upload horario e no salas.js mudas para upload-salas
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            return response.text();
        }
        throw new Error('Falha ao salvar o arquivo.');
    })
    .then(text => console.log(text))
    .catch(error => console.error(error));
}

function exportTabulatorToCSV() {
    var headers = table.getColumns().filter(column => column.isVisible()).map(column => column.getDefinition().title);
    var csvContent = [headers.join(';')];

    table.getData().forEach(row => {
        var rowData = headers.map(header => row[header]);
        csvContent.push(rowData.join(';'));
    });

    return csvContent.join('\n');
}
function saveFileToServer() {
    // Primeiro, converte os dados do Tabulator para CSV
    var csvContent = exportTabulatorToCSV();
    var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });

    // Em seguida, cria um FormData e adiciona o blob do CSV a ele
    var formData = new FormData();
    formData.append('file', blob, 'HorarioDeExemploAtualizado.csv');

    // Finalmente, faz o upload para o servidor
    fetch('/upload-horarios', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            alert("Ficheiro guardado com sucesso!");
        } else {
            throw new Error('Falha ao guardar o ficheiro.');
        }
    })
    .catch(error => {
        console.error('Erro ao guardar o ficheiro:', error);
        alert("Erro ao guardar o ficheiro.");
    });
}
function fetchScheduleFile() {
    fetch('/HorarioDeExemploAtualizado.csv')
        .then(response => response.text())
        .then(csvData => {
            const data = parseCSV(csvData);
            createTable(data.headers, data.data);
            createColumnControls(data.headers);
        })
        .catch(error => {
            console.error('Erro ao carregar o ficheiro do servidor:', error);
        });
}
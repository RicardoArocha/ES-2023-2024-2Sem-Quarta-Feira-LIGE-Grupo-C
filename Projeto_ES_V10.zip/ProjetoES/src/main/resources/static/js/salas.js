let table;
let roomData = []; // Dados das salas
let scheduleData = []; // Dados dos horários

document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('csvFileInput').addEventListener('change', handleFileSelect2, false);
    // Suponhamos que você tenha um botão com id 'loadScheduleButton' para carregar o horário
    loadRoomData();
    loadScheduleData();
});


function handleFileSelect2(event) {
    const file = event.target.files[0];
    parseFile2(file);
}

function parseFile2(file) {
    const reader = new FileReader();
    reader.onload = function(e) {
        const contents = e.target.result;
        const data = parseCSV(contents);
        createTable(data.headers, data.data);
    };
    reader.readAsText(file); // Especifica UTF-8 aqui
}





function loadRoomData() {
    const roomCsvUrl = '/caracterizacaodasSalas.csv';
    fetch(roomCsvUrl)
        .then(response => response.text())
        .then(csvData => {
            const parsedData = parseCSV2(csvData);
            roomData = parsedData.data;
            console.log("Dados das salas carregados", roomData);
        })
        .catch(error => console.error('Erro ao carregar os dados das salas:', error));
}

function loadScheduleData() {
    const scheduleCsvUrl = '/HorarioDeExemploAtualizado.csv';
    fetch(scheduleCsvUrl)
        .then(response => response.text())
        .then(csvData => {
            const parsedData = parseCSV2(csvData);
            scheduleData = parsedData.data;
            console.log("Dados dos horários carregados", scheduleData);
        })
        .catch(error => console.error('Erro ao carregar os dados dos horários:', error));
}

function parseCSV2(csvData) {
    // Divide o CSV em linhas.
    const rows = csvData.trim().split('\n');

    // Log da primeira linha para confirmar os cabeçalhos.
 
   
    // Extrai os cabeçalhos da primeira linha.
    const headers = rows.shift().split(';').map(header => header.trim());

    // Log do array de cabeçalhos para confirmar que estão corretos.


    // Processa cada linha para transformá-la em um objeto baseado nos cabeçalhos.
    const data = rows.map((row, rowIndex) => {
        // Log da linha bruta.


        // Divide a linha pelo delimitador e remove espaços extras.
        const values = row.split(';').map(value => value.trim());

        // Cria um objeto para armazenar os dados da linha.
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = values[index] || "";
        });

        // Log do objeto criado a partir da linha para confirmar que está correto.
       

        return obj;
    });

    return { headers, data };
}


function checkAvailability() {
    const startTimeInput = document.getElementById('startTime').value;
    const dayInput = document.getElementById('dayOfWeek').value;
    const searchDate = dayInput.split('-').reverse().join('/');
    const searchStartTime = convertTimeToComparableFormat(startTimeInput);

    console.log(`Procurando disponibilidade para: ${searchDate} às ${searchStartTime} minutos`);

    // Filtra primeiro os horários que batem com a data e hora de busca
    const relevantSchedules = scheduleData.filter(schedule => {
        let roomBookedDate = schedule['Data da aula'];
        let roomStartTime = convertTimeToComparableFormat(schedule['Hora início da aula']);
        let roomEndTime = convertTimeToComparableFormat(schedule['Hora fim da aula']);

        let isSameDate = roomBookedDate === searchDate;
        let isTimeOverlap = searchStartTime >= roomStartTime && searchStartTime < roomEndTime;

        const logMessage = `Sala ${schedule['Sala atribuída à aula']} no dia ${schedule['Data da aula']} das ${schedule['Hora início da aula']} até ${schedule['Hora fim da aula']}: Data igual? ${isSameDate}, Hora se sobrepõe? ${isTimeOverlap}`;
        
        // Aqui adicionamos o log para cada horário relevante
        if (isSameDate && isTimeOverlap) {
            const room = roomData.find(r => r['Nome sala'] === schedule['Sala atribuída à aula']);
            const capacity = room ? room['Capacidade Normal'] : 'Desconhecida';
            console.log(`Sala ${schedule['Sala atribuída à aula']} no dia ${schedule['Data da aula']} das ${schedule['Hora início da aula']} até ${schedule['Hora fim da aula']}: Data igual? ${isSameDate}, Hora se sobrepõe? ${isTimeOverlap}, Capacidade Normal: ${capacity}`);
            console.log(logMessage);
        }
        
        return isSameDate && isTimeOverlap;
    });

    console.log(`Total de horários relevantes: ${relevantSchedules.length}`);
    console.log(`Horários relevantes encontrados: ${relevantSchedules.length}`);
    relevantSchedules.forEach(schedule => {
        console.log(`Sala ${schedule['Sala atribuída à aula']} está ocupada das ${schedule['Hora início da aula']} às ${schedule['Hora fim da aula']} no dia ${schedule['Data da aula']}`);
    });

    // Depois, verifica quais salas estão ocupadas nesses horários específicos
    let availableRooms = roomData.map(room => {
        let isBooked = relevantSchedules.some(schedule => {
            return schedule['Sala atribuída à aula'] === room['Nome sala'];
        });

        console.log(`Sala ${room['Nome sala']}: ${isBooked ? 'Ocupada' : 'Disponível'}`);

        return {
            roomName: room['Nome sala'],
            available: !isBooked
        };
    });

    console.log(`Total de salas verificadas: ${availableRooms.length}`);
    let availableRoomsList = availableRooms.filter(r => r.available);
    console.log(`Salas disponíveis após filtragem: ${availableRoomsList.length}`);
    console.log(`Salas disponíveis: ${availableRoomsList.map(r => r.roomName).join(', ')}`);

    updateTable(availableRoomsList);
}


// Resto das funções auxiliares...


// Resto das funções auxiliares...



function convertTimeToComparableFormat(timeString) {
    let [hours, minutes] = timeString.split(':').map(Number);
    return hours * 60 + minutes; // retorna o total em minutos
}




function convertTimeToMinutes(timeString) {
    const [hours, minutes] = timeString.split(':').map(Number);
    return (hours * 60) + minutes;
}

function updateTable(availableRooms) {
    // Obtenha os nomes das salas disponíveis a partir do availableRooms.
    const availableRoomNames = new Set(availableRooms.map(room => room.roomName));

    if (table) {
        // Obtenha os dados atuais da tabela.
        const currentData = table.getData();

        // Filtre os dados para incluir apenas aqueles cujos nomes estão em availableRoomNames.
        const filteredData = currentData.filter(row => availableRoomNames.has(row['Nome sala']));

        // Atualize a tabela com os dados filtrados.
        table.setData(filteredData).then(function() {
            console.log('Tabela atualizada com sucesso.');
        }).catch(function(error) {
            console.error('Erro ao atualizar a tabela:', error);
        });
    } else {
        console.error('A tabela Tabulator não foi inicializada.');
    }
}







function resetFilters() {
    // Limpando o input de data e hora
    document.getElementById('startTime').value = '';
    document.getElementById('dayOfWeek').value = '';

    // Aqui você pode redefinir os dados da tabela para o estado inicial, se tiver esses dados armazenados
    // Por exemplo, se você carrega todos os dados das salas ao iniciar a aplicação, pode apenas redefinir a tabela
    if(table) {
        table.clearFilter(true); // remove filtros, mas mantém os dados da tabela
        table.setData(roomData); // redefine os dados da tabela para o conjunto de dados original
    } else {
        console.error('A tabela Tabulator não foi inicializada.');
    }
}













function parseCSV(csvData) {
    const rows = csvData.trim().split('\n').map(row => row.split(';').map(field => field.trim()));
    const headers = rows.shift(); // Remove a primeira linha e considera-a como cabecalhos
    const data = rows.map(row => {
        const obj = {};
        headers.forEach((header, index) => {
            obj[header] = row[index];
        });
        return obj;
    });
    return { headers, data };
}

function createTable(headers, data) {
    // Identifica os cabeçalhos de Laboratórios e Arquivos
    const labHeaders = headers.filter(header => header.startsWith('Laborat'));
    const arqHeaders = headers.filter(header => header.startsWith('Arq'));

    // Filtra os cabeçalhos originais para excluir Laboratórios e Arquivos
    const filteredHeaders = headers.filter(header => !labHeaders.includes(header) && !arqHeaders.includes(header));

    // Mapeia os cabeçalhos filtrados para colunas do Tabulator
    const columns = filteredHeaders.map(header => ({
        title: header,
        field: header,
        headerFilter: 'input'
    }));

    // Cria as colunas de Laboratórios e Arquivos no local desejado
    columns.splice(5, 0, {
        title: "Laboratórios",
        field: "Laboratórios",
        headerFilter: 'input',
    });
    columns.splice(6, 0, {
        title: "Arquivos",
        field: "Arquivos",
        headerFilter: 'input'
    });

    // Processa os dados para combinar os valores de Laboratórios e Arquivos
    const processedData = data.map(row => {
        const labs = labHeaders.map(header => row[header] === 'X' ? header.replace('Laboratório de ', '') : '').filter(Boolean);
        const arqs = arqHeaders.map(header => row[header] === 'X' ? header.replace('Arquivo de ', '') : '').filter(Boolean);

        return {
            ...row,
            Laboratórios: labs.join('; '),
            Arquivos: arqs.join('; ')
        };
    });

    // Cria a instância do Tabulator com os dados processados
    table = new Tabulator("#tableContainer", {
        data: processedData,
        columns: columns,
        layout: "fitData",
        pagination: "local",
        paginationSize: 10,
        paginationSizeSelector: [5, 10, 20, 50],
        movableColumns: true,
        resizableRows: true,
        initialSort: [{ column: filteredHeaders[0], dir: "asc" }]
    });
}



/* metes esta função no salas.js */

function uploadFile2() {
    var updatedCSV = exportTabulatorToCSV();
    var blob = new Blob([updatedCSV], { type: 'text/csv;charset=utf-8;' });
    

    var formData = new FormData();
    formData.append('file', blob, 'caracterizacaodassalas.csv');
    //aqui vais ter de mudar de upload para upload horario e no salas.js mudas para upload-salas
    fetch('/upload', {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if(response.ok) {
            return response.text();
        }
        throw new Error('Falha ao salvar o arquivo.');
    })
    .then(text => console.log(text))
    .catch(error => console.error(error));
}

function exportTabulatorToCSV() {
    var headers = table.getColumns().filter(column => column.isVisible()).map(column => column.getDefinition().title);
    var csvContent = [headers.join(';')];

    table.getData().forEach(row => {
        var rowData = headers.map(header => row[header]);
        csvContent.push(rowData.join(';'));
    });

    return csvContent.join('\n');
}






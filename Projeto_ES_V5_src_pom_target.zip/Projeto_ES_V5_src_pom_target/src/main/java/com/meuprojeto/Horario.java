package com.meuprojeto;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

@Document(collection = "horarios")
public class Horario {
    @Id
    private String id;
    
    //JsonProperty- para mapear propriedades de um objeto Java para chaves específicas em objetos JSON e vice-versa
    @JsonProperty("Curso")
    private String Curso;
    
    @JsonProperty("Unidade_Curricular")
    private String Unidade_Curricular;
    
    @JsonProperty("Turno")
    private String Turno;
    
    @JsonProperty("Turma")
    private String Turma;
    
    @JsonProperty("Inscritos_no_turno")
    private String Inscritos_no_turno;
    
    @JsonProperty("Dia_da_semana")
    private String Dia_da_semana;
    
    @JsonProperty("Hora_inicio_da_aula")
    private String Hora_inicio_da_aula;
    
    @JsonProperty("Hora_fim_da_aula")
    private String Hora_fim_da_aula;
    
    @JsonProperty("Data_da_aula")
    private String Data_da_aula;
    
    @JsonProperty("Caracteristicas_da_sala_pedida_para_a_aula")
    private String Caracteristicas_da_sala_pedida_para_a_aula;
    
    @JsonProperty("Sala_atribuida_a_aula")
    private String Sala_atribuida_a_aula;
    
    @JsonProperty("Semana_do_Ano")
    private String Semana_do_Ano;
    
    @JsonProperty("Semana_do_1_Semestre")
    private String Semana_do_1_Semestre;
    
    @JsonProperty("Semana_do_2_Semestre")
    private String Semana_do_2_Semestre;;

    // Construtores

    public Horario() {
    }

    public Horario(String Curso, String Unidade_Curricular, String Turno, String Turma, String Inscritos_no_turno,
                   String Dia_da_semana, String Hora_inicio_da_aula, String Hora_fim_da_aula, String Data_da_aula,
                   String Caracteristicas_da_sala_pedida_para_a_aula, String Sala_atribuida_a_aula, String Semana_do_Ano,
                   String Semana_do_1_Semestre, String Semana_do_2_Semestre) {
        this.Curso = Curso;
        this.Unidade_Curricular = Unidade_Curricular;
        this.Turno = Turno;
        this.Turma = Turma;
        this.Inscritos_no_turno = Inscritos_no_turno;
        this.Dia_da_semana = Dia_da_semana;
        this.Hora_inicio_da_aula = Hora_inicio_da_aula;
        this.Hora_fim_da_aula = Hora_fim_da_aula;
        this.Data_da_aula = Data_da_aula;
        this.Caracteristicas_da_sala_pedida_para_a_aula = Caracteristicas_da_sala_pedida_para_a_aula;
        this.Sala_atribuida_a_aula = Sala_atribuida_a_aula;
        this.Semana_do_Ano = Semana_do_Ano;
        this.Semana_do_1_Semestre = Semana_do_1_Semestre;
        this.Semana_do_2_Semestre = Semana_do_2_Semestre;
    }

    // Getters e Setters

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCurso() {
        return Curso;
    }

    public void setCurso(String Curso) {
        this.Curso = Curso;
    }

    public String getUnidade_Curricular() {
        return Unidade_Curricular;
    }

    public void setUnidade_Curricular(String Unidade_Curricular) {
        this.Unidade_Curricular = Unidade_Curricular;
    }

    public String getTurno() {
        return Turno;
    }

    public void setTurno(String Turno) {
        this.Turno = Turno;
    }

    public String getTurma() {
        return Turma;
    }

    public void setTurma(String Turma) {
        this.Turma = Turma;
    }

    public String getInscritos_no_turno() {
        return Inscritos_no_turno;
    }

    public void setInscritos_no_turno(String Inscritos_no_turno) {
        this.Inscritos_no_turno = Inscritos_no_turno;
    }

    public String getDia_da_semana() {
        return Dia_da_semana;
    }

    public void setDia_da_semana(String Dia_da_semana) {
        this.Dia_da_semana = Dia_da_semana;
    }

    public String getHora_inicio_da_aula() {
        return Hora_inicio_da_aula;
    }

    public void setHora_inicio_da_aula(String Hora_inicio_da_aula) {
        this.Hora_inicio_da_aula = Hora_inicio_da_aula;
    }

    public String getHora_fim_da_aula() {
        return Hora_fim_da_aula;
    }

    public void setHora_fim_da_aula(String Hora_fim_da_aula) {
        this.Hora_fim_da_aula = Hora_fim_da_aula;
    }

    public String getData_da_aula() {
        return Data_da_aula;
    }

    public void setData_da_aula(String Data_da_aula) {
        this.Data_da_aula = Data_da_aula;
    }

    public String getCaracteristicas_da_sala_pedida_para_a_aula() {
        return Caracteristicas_da_sala_pedida_para_a_aula;
    }

    public void setCaracteristicas_da_sala_pedida_para_a_aula(String Caracteristicas_da_sala_pedida_para_a_aula) {
        this.Caracteristicas_da_sala_pedida_para_a_aula = Caracteristicas_da_sala_pedida_para_a_aula;
    }

    public String getSala_atribuida_a_aula() {
        return Sala_atribuida_a_aula;
    }

    public void setSala_atribuida_a_aula(String Sala_atribuida_a_aula) {
        this.Sala_atribuida_a_aula = Sala_atribuida_a_aula;
    }

    public String getSemana_do_Ano() {
        return Semana_do_Ano;
    }

    public void setSemana_do_Ano(String Semana_do_Ano) {
        this.Semana_do_Ano = Semana_do_Ano;
    }

    public String getSemana_do_1_Semestre() {
        return Semana_do_1_Semestre;
    }

    public void setSemana_do_1_Semestre(String Semana_do_1_Semestre) {
        this.Semana_do_1_Semestre = Semana_do_1_Semestre;
    }

    public String getSemana_do_2_Semestre() {
        return Semana_do_2_Semestre;
    }

    public void setSemana_do_2_Semestre(String Semana_do_2_Semestre) {
        this.Semana_do_2_Semestre = Semana_do_2_Semestre;
    }
}
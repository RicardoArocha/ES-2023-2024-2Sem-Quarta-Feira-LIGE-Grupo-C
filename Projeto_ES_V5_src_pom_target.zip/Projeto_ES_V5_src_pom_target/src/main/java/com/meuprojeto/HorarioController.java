package com.meuprojeto;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.lang.NonNull;
import javax.validation.Valid;

@RestController
public class HorarioController {
    
    private static final Logger logger = LoggerFactory.getLogger(HorarioController.class);
    
    @Autowired
    private HorarioRepository horarioRepository; 

    @PostMapping("/save-data")
    public ResponseEntity<String> saveData(@Valid @NonNull @RequestBody List<Horario> horarios) {
        try {
            logger.info("Recebidos {} horários para salvar.", horarios.size());

            // Salvar os dados recebidos no MongoDB
            // salva se ainda não existirem e dá update se ja existirem- MAS o eles tem todos um id diferente
            //portanto nao esta formatado para dar update
            horarioRepository.saveAll(horarios);
          
            logger.info("Dados salvos com sucesso!-BACKEND");
            return new ResponseEntity<>("Dados salvos com sucesso!", HttpStatus.OK);
        } catch (Exception e) {
            // Log da exceção para investigação
            logger.error("Erro ao salvar os dados:", e);
            return new ResponseEntity<>("Ocorreu um erro ao salvar os dados.", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}

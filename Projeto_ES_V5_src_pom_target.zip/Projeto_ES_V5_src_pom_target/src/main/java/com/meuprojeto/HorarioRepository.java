package com.meuprojeto;
import org.springframework.data.mongodb.repository.MongoRepository;


public interface HorarioRepository extends MongoRepository<Horario, Object>{

}